﻿
using Task_3_1;

namespace Task_3_1
{
    public class Program
    {
        public static void Main(string[] args)
        {

            IdentifiableObject id = new IdentifiableObject(new string[] { "007", "James", "Bond" });

        }
    }
}