using SplashKitSDK;
using System.Collections.Generic;
using System.IO;


namespace Task_4
{
    public class Drawing
    {
        private readonly List<Shape> _shapes;
        private Color _background;

        public Color Background
        {
            get { return _background; }
            set { _background = value; }
        }

        public Drawing(Color background)
        {
            _shapes = new List<Shape>();
            _background = background;
        }

        public Drawing() : this(Color.White)
        {
        }

        public int ShapeCount
        {
            get { return _shapes.Count; }
        }

        // Changed return type from Shape to void.
        public void AddShape(Shape s)
        {
            _shapes.Add(s);
        }

        // Changed return type from Shape to void.
        public void RemoveShape(Shape s)
        {
            _shapes.Remove(s);
        }

        public void Draw()
        {
            SplashKit.ClearScreen(_background);
            foreach (Shape s in _shapes)
            {
                s.Draw();
            }
        }

        public void SelectShapesAt(Point2D pt)
        {
            foreach (Shape s in _shapes)
            {
                s.Selected = s.IsAt(pt);
            }
        }

        public List<Shape> SelectedShapes
        {
            get
            {
                List<Shape> result = new List<Shape>();
                foreach (Shape s in _shapes)
                {
                    if (s.Selected)
                    {
                        result.Add(s);
                    }
                }
                return result;
            }
        }

        public void Save(string filename)
        {
            using (var writer = new StreamWriter(filename))
            {
                writer.WriteColor(Background);
                writer.WriteLine(ShapeCount);
                foreach (var s in _shapes)
                {
                    s.SaveTo(writer);
                }
            }

        }

        public void Load(string filename)
        {
            StreamReader reader = new StreamReader(filename);
            try
            {
                Background = reader.ReadColor();
                int count = reader.ReadInteger();
                _shapes.Clear();
                for (int i = 0; i < count; i++)
                {
                    string kind = reader.ReadLine();
                    Shape s;
                    switch (kind)
                    {
                        case "Rectangle":
                            s = new MyRectangle();
                            break;
                        case "Circle":
                            s = new MyCircle();
                            break;
                        case "Line":
                            s = new MyLine();
                            break;
                        case "Ellipse":
                            s = new MyEllipse();
                            break;
                        case "MyName":
                            s = new MyName();
                            break;

                        default:
                            throw new InvalidDataException("Unkown Shape Kind" + kind);
                    }
                    s.LoadFrom(reader);
                    _shapes.Add(s);

                }
            }
            finally
            {
                reader.Close();
            }
        }
        public void ChangeColors()
        {
            foreach (Shape s in _shapes)
            {
                s.Color = SplashKit.RandomColor();
            }
        }
    }
}

